SYNTHETIC RELEASE FIXTURE
This archive contains only demonstration text, not a runnable product.
